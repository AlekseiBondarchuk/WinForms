﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab12
{
    public partial class Form1 : Form
    {
        bool drawing;
        int historyCounter = 0;
        static int historyLenght = 10;
        GraphicsPath currentPath;
        Point oldLocation;
        Pen currentPen;
        internal Color currentColor = Color.Black;
        List<Image> History;
        internal ColorsForm color_chose;

        public Form1()
        {
            InitializeComponent();
            drawing = false;
            currentPen = new Pen(Color.Black);
            currentPen.Width = trackBar1.Value;
            History = new List<Image>();
            this.newCtrlNToolStripMenuItem_Click(this, new EventArgs());
            color_chose = new ColorsForm(currentPen.Color);
            color_chose.Owner = this;
        }

        private void picDrawingSurface_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left || e.Button == MouseButtons.Right)
            {
                if (e.Button == MouseButtons.Left)
                {
                    currentPen.Color = currentColor;
                }
                else
                {
                    currentPen.Color = Color.White;
                }
                drawing = true;
                oldLocation = e.Location;
                currentPath = new GraphicsPath();
            }
        }
        private void picDrawingSurface_MouseUp(object sender, MouseEventArgs e)
        {
            History.RemoveRange(historyCounter + 1, History.Count -historyCounter - 1);
            History.Add(new Bitmap(picDrawingSurface.Image));
            if (historyCounter >= historyLenght)
            {
                History.RemoveAt(0);
            }
            else
            {
                historyCounter++;
            }
                
            drawing = false;
            try
            {
                currentPath.Dispose();
            }
            catch { };
        }

        private void picDrawingSurface_MouseMove(object sender, MouseEventArgs e)
        {
            label.Text = (picDrawingSurface.Width/2 - e.X).ToString() + ", " + (picDrawingSurface.Height/2 - e.Y).ToString();
            if (drawing)
            {
                Graphics g = Graphics.FromImage(picDrawingSurface.Image);
                currentPath.AddLine(oldLocation, e.Location);
                g.DrawPath(currentPen, currentPath);
                oldLocation = e.Location;
                g.Dispose();
                picDrawingSurface.Invalidate();
            }
        }

        private void newCtrlNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (picDrawingSurface.Image != null)
            {
                var result = MessageBox.Show("Сохранить текущее изображение перед созданием нового рисунка ? ", "Предупреждение", MessageBoxButtons.YesNoCancel);
                switch (result)
                {
                    case DialogResult.No: break;
                    case DialogResult.Yes: saveF2ToolStripMenuItem_Click(sender, e); break;
                    case DialogResult.Cancel: return;
                }
            }
            History.Clear();
            historyCounter = 0;
            Bitmap pic = new Bitmap(picDrawingSurface.Size.Width, picDrawingSurface.Size.Height);
            Graphics g = Graphics.FromImage(pic);
            g.Clear(Color.White);
            picDrawingSurface.Image = pic;
            History.Add(new Bitmap(picDrawingSurface.Image));
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.newCtrlNToolStripMenuItem_Click(sender, e);
        }

        private void saveF2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveDlg.ShowDialog();
            if (SaveDlg.FileName != "") 
            {
                System.IO.FileStream fs = (System.IO.FileStream)SaveDlg.OpenFile();
                switch (SaveDlg.FilterIndex)
                {
                    case 1:
                        this.picDrawingSurface.Image.Save(fs,
                        ImageFormat.Jpeg);
                        break;
                    case 2:
                        this.picDrawingSurface.Image.Save(fs,
                        ImageFormat.Bmp);
                        break;
                    case 3:
                        this.picDrawingSurface.Image.Save(fs,
                        ImageFormat.Gif);
                        break;
                    case 4:
                        this.picDrawingSurface.Image.Save(fs,
                        ImageFormat.Png);
                        break;
                }
                fs.Close();
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            saveF2ToolStripMenuItem_Click(sender, e);
        }

        private void openF3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (picDrawingSurface.Image != null)
            {
                var result = MessageBox.Show("Сохранить текущее изображение перед созданием нового рисунка ? ", "Предупреждение", MessageBoxButtons.YesNoCancel);
                switch (result)
                {
                    case DialogResult.No: break;
                    case DialogResult.Yes: saveF2ToolStripMenuItem_Click(sender, e); break;
                    case DialogResult.Cancel: return;
                }
            }
            if (OP.ShowDialog() != DialogResult.Cancel)
            {
                picDrawingSurface.Load(OP.FileName);
                if (picDrawingSurface.Width < panel2.Width || picDrawingSurface.Height < panel2.Height)
                {
                    History.Clear();
                    historyCounter = 0;
                    Bitmap pic = new Bitmap(panel2.Size.Width, panel2.Size.Height);
                    Graphics g = Graphics.FromImage(pic);
                    g.Clear(Color.White);
                    g.DrawImage(picDrawingSurface.Image,0,0);
                    picDrawingSurface.Image = pic;
                    History.Add(new Bitmap(picDrawingSurface.Image));
                }
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            openF3ToolStripMenuItem_Click(sender, e);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            currentPen.Width = trackBar1.Value;
        }

        private void exitAltXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            exitAltXToolStripMenuItem_Click(sender,e);
        }

        private void undoCtrlZToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (History.Count != 0 && historyCounter != 0)
            {
                picDrawingSurface.Image = new Bitmap(History[--historyCounter]);
            }
            else
            {
                MessageBox.Show("История пуста");
            }
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (historyCounter < History.Count - 1)
            {
                picDrawingSurface.Image = new Bitmap(History[++historyCounter]);
            }
            else MessageBox.Show("История пуста");
        }

        private void solodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.Solid;
            solodToolStripMenuItem.Checked = true;
            dotToolStripMenuItem.Checked = false;
            dashDotDotToolStripMenuItem.Checked = false;
        }

        private void dotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.Dot;
            solodToolStripMenuItem.Checked = false;
            dotToolStripMenuItem.Checked = true;
            dashDotDotToolStripMenuItem.Checked = false;
        }

        private void dashDotDotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.DashDotDot;
            solodToolStripMenuItem.Checked = false;
            dotToolStripMenuItem.Checked = false;
            dashDotDotToolStripMenuItem.Checked = true;
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            color_chose.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            colorToolStripMenuItem_Click(sender, e);
        }

        private void picDrawingSurface_Click(object sender, EventArgs e)
        {

        }

        private void label_Click(object sender, EventArgs e)
        {

        }
    }
}
